from rest_framework import viewsets
from .models import eventdetails
from . import serializers

class EventViewsets(viewsets.ModelViewSet):
    queryset = eventdetails.objects.all()
    serializer_class = serializers.EventSerializer
    
