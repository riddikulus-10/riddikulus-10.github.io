from rest_framework.views import APIView
from rest_framework.response import Response

class VisualEndpoint(APIView):

    @classmethod
    def get_extra_actions(cls):
        return []

class passenger(VisualEndpoint):

    def get(self, request):
        return Response(help.baggage_belts().to_dict())
