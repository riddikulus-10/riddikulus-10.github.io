from rest_framework import serializers
from . import models

class EventSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = models.eventdetails
        fields = ('id', 'url', 'event', 'time')
