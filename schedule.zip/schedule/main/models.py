from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class eventdetails(models.Model):
    url = models.URLField(max_length=200)
    event = models.CharField(max_length=200)
    time = models.DateTimeField()
